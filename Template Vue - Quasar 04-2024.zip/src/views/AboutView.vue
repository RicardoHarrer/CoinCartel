<template>
  <div>
    <p class="text-h3 text-center q-mt-xl">About Page</p>
  </div>
</template>
